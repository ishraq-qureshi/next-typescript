import Employee from "./classes/Employee.class";
import FetchApi from "./classes/FetchApi.class";
import { EmployeeDetails } from "./types/Employee.type";

async function fetchEmployeesRecord(callback: (data: EmployeeDetails[]) => void) {
  try {
    await FetchApi.FetchGetRequest<EmployeeDetails[]>("https://dummy.restapiexample.com/api/v1/employees", callback);    
  } catch (err) {
    console.error('Fetch error:', err);
  }
}

fetchEmployeesRecord((data: EmployeeDetails[]) => {
  const employee = new Employee(data);
  console.log(employee.getAllEmployees());
});