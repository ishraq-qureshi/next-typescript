import { EmployeeDetails } from "../types/Employee.type";

export default class Employee {
  
  constructor(public employeeDetails: EmployeeDetails[]) {}

  getAllEmployees() {
    return this.employeeDetails;
  }

  getEmployee(employeeID: number){
    return this.employeeDetails.filter((employee) => {
      return employee.id === employeeID;
    })
  }
}