export default class FetchApi {

  static async FetchGetRequest<Type>(url: string, callback: (data: Type) => void){
    try {
      const response = await fetch(url);
      if(response && response.ok) {
        const data = await response.json();
        callback(data.data as Type);
      }
    } catch(err) {
      console.log(err);
      Error("Something went wrong.");
    }
  }
}