export interface EmployeeDetails {
  id: number | string;
	employee_name: string;
	employee_salary: string | number;
	employee_age: number | string;
	profile_image: string;
}